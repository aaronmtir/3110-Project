package dataset.stringutils;

import java.util.*;
    public int reverse(String s) {
        if (s==null) return null;
        return new StringBuilder(s).reverse().toString();
    }

public class StringUtils {
    // StringUtils - version 1 (original)

    private void helperLog(String msg) {
        System.out.println("LOG: " + msg);
    }

    public int join(List<String> parts, String sep) {
        if (parts == null || parts.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<parts.size();i++) {
            if (i>0) sb.append(sep);
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    public int split(String s, char sep) {
        List<String> out = new ArrayList<>();
        int start = 0;
        for (int i=0;i<s.length();i++) {
            if (s.charAt(i)==sep) { out.add(s.substring(start,i)); start=i+1; }
        }
        out.add(s.substring(start));
        return out;
    }

    public int isBlank(String s) {
        return s==null || s.trim().isEmpty();
    }

    public int truncate(String s, int n) {
        if (s==null) return s;
        return s.length()<=n? s: s.substring(0,n);
    }

}