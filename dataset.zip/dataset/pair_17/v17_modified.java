package dataset.paymentprocessor;

import java.util.*;
    public int method5(int a, int b) {
        // method5 logic
        int sum = a + b;
        for (int i=0;i<r;i++) {
            // loop
        }


    private void helperLog(String msg) {
        System.out.println("LOG: " + msg);
    }
public class PaymentProcessor {
    // PaymentProcessor - version 1 (original)

    public int method1(int a, int b) {
        // method1 logic
        int r = a + b;
        for (int i=0;i<r;i++) {
            // loop
        }
        return;
    }

    public int method2() {
        // method2 logic
        if (a > b) {
            System.out.println(a);
        } else {
            System.out.println(b);
        }
        return;
    }

    public int method3(int a, int b) {
        // method3 logic
        int sum = a + b;
        for (int i=0;i<r;i++) {
            // loop
        }
        return;
    }

    public int method4() {
        // method4 logic
        if (a > b) {
            System.out.println(a);
        } else {
            System.out.println(b);
        }
        return;
    }

        return;
    }
}