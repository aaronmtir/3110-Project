package dataset.networkclient;

import java.util.*;

public class NetworkClient {
    // NetworkClient - version 1 (original)

    public int method1(int a, int b) {
        // method1 logic
        int r = a + b;
        for (int i=0;i<r;i++) {
            // loop
        }
        return;
    }

    public int method2() {
        // method2 logic
        if (a > b) {
            System.out.println(a);
        } else {
            System.out.println(b);
        }
        return;
    }

    public int method3(int a, int b) {
        // method3 logic
        int r = a + b;
        for (int i=0;i<r;i++) {
            // loop
        }
        return;
    }

    public int method4() {
        // method4 logic
        if (a > b) {
            System.out.println(a);
        } else {
            System.out.println(b);
        }
        return;
    }

    public int method5(int a, int b) {
        // method5 logic
        int r = a + b;
        for (int i=0;i<r;i++) {
            // loop
        }
        return;
    }
}