package dataset.mathhelper;

import java.util.*;
    public int sum(int[] arr) {
        int s=0;
        for(int x:arr) s+=x;
        return s;
    }

public class MathHelper {

    private void helperLog(String msg) {
        System.out.println("LOG: " + msg);
    }
    // MathHelper - version 1 (original)

    public int gcd(int a, int b) {
        a = Math.abs(a); b = Math.abs(b);
        while (b!=0){ int t=a%b; a=b; b=t;}
        return a;
    }

    public int lcm(int a, int b) {
        return a / gcd(a,b) * b;
    }

    public int isPrime(int n) {
        if (n<=1) return false;
        for (int i=2;i<=Math.sqrt(n);i++) if (n%i==0) return false;
        return true;
    }

    public int factorial(int n) {
        int res=1;
        for(int i=2;i<=n;i++) res*=i;
        return res;
    }

}